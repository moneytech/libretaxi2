package objects

type Post struct {
	PostId int64
	UserId int64
	Text string
	Lon float64
	Lat float64
	ReportCnt int
}

